# Load libraries
install.packages(c("keras", "tensorflow"))
library(keras)
library(tensorflow)
library(zeallot)  # Needed for %<-% unpacking

# Load Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
c(x_train, y_train) %<-% fashion_mnist$train
c(x_test, y_test) %<-% fashion_mnist$test

# Class labels
class_names <- c(
  "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat", 
  "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
)

# Normalize and reshape
x_train <- x_train / 255
x_test <- x_test / 255
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test <- array_reshape(x_test, c(nrow(x_test), 28, 28, 1))

# Convert labels to categorical (no named arguments)
y_train_cat <- to_categorical(y_train, 10)
y_test_cat <- to_categorical(y_test, 10)

# Define CNN model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = "relu", 
                input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 10, activation = "softmax")

# Compile
model %>% compile(
  loss = "categorical_crossentropy",
  optimizer = optimizer_adam(),
  metrics = "accuracy"
)

# Train
history <- model %>% fit(
  x_train, y_train_cat,
  epochs = 5, batch_size = 128,
  validation_split = 0.2
)

# Evaluate
score <- model %>% evaluate(x_test, y_test_cat)
cat("Test loss:", score$loss, "\n")
cat("Test accuracy:", score$accuracy, "\n")

# Predictions
predictions <- model %>% predict(x_test)

# Plot first 10 predictions with actual labels
par(mfrow = c(2,5), mar = c(2,2,2,2))
for (i in 1:10) {
  img <- x_test[i,,,1]
  predicted_label <- which.max(predictions[i,]) - 1
  true_label <- y_test[i]
  
  image(1:28, 1:28, t(apply(img, 2, rev)), col = gray.colors(255), axes = FALSE)
  title(
    main = paste0("Pred: ", class_names[predicted_label + 1], 
                  "\nActual:
